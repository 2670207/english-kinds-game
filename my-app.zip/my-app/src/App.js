import './App.css';
import Header from './components/Header';
import Nav from './components/Nav';
import { Provider, useSelector} from 'react-redux';
import Cards from './components/game/Cards';
import GameFinishSuccess from './components/GameFinishSuccess'
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { createStore  } from '@reduxjs/toolkit';
import { rootReducer} from './redux/reducer';

const store = createStore(rootReducer);
export default function App() {

  return (
    <Provider store={store}>
        <Router>
          <Header>
            <Nav></Nav>
          </Header> 
  
          <Switch>
            
            {true && <Route path="/category/:id" component={Cards}></Route>}
            <Route path="/game-success" component={GameFinishSuccess}></Route>
            
          </Switch>
      </Router>
    </Provider>
  );
}

