import { configureStore } from '@reduxjs/toolkit';
import gameStatusSlice from './reducer'

export default configureStore({
  reducer: {
    gameStatusSlice: gameStatusSlice,
  },
});