import { createSlice } from '@reduxjs/toolkit'

const initialState = { value: 0 }

const counterSlice = createSlice({
  name: 'game-status',
  initialState,
  reducers: {
    increment(state) {
      state.value++
    },
    decrement(state) {
      state.value--
    },
    incrementByAmount(state, action) {
      state.value += action.payload
    },
  },
})
export const selectCount = state => state.counter.value;
export const { increment, decrement, incrementByAmount } = counterSlice.actions
export default counterSlice.reducer