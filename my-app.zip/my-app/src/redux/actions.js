import { SET_STATUS_MODE_TRAINING, SET_STATUS_MODE_GAME, SET_STATUS_GAME_PLAY, SET_STATUS_GAME_STOP } from "./types";

export function setStatusModeTraining(){
    return {
        type: SET_STATUS_MODE_TRAINING
    }
}

export function setStatusModeGame(){
    return {
        type: SET_STATUS_MODE_GAME   
    }
}
export function setStatusGamePlay(){
    return {
        type: SET_STATUS_GAME_PLAY
    }
}

export function setStatusGameStop(){
    return {
        type: SET_STATUS_GAME_STOP   
    }
}