import { combineReducers } from "@reduxjs/toolkit";
import {gameReducer} from './reducers/game';

export const rootReducer = combineReducers({
    game:  gameReducer,
})
