import { SET_STATUS_MODE_TRAINING, SET_STATUS_MODE_GAME, SET_STATUS_GAME_PLAY, SET_STATUS_GAME_STOP } from "../types";

const initialState = {
    isModeTraining: true,
    isRun: false,
}
export const gameReducer = (state = initialState, action) => {
    switch(action.type){
        case SET_STATUS_MODE_TRAINING: 
            return {...state, isModeTraining: true}
        case SET_STATUS_MODE_GAME: 
            return {...state, isModeTraining: false}
        case SET_STATUS_GAME_PLAY:
            return {...state, isRun: true}
        case SET_STATUS_GAME_STOP: 
            return {...state, isRun: false}
            
        default: return state;
    }
}