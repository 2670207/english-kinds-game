import React from 'react';
import { connect } from 'react-redux';
import {setStatusModeTraining, setStatusModeGame} from '../redux/actions';

class Header extends React.Component {
    constructor(props){
      super(props);
      this.state = { checkbox: this.props.game.isModeTraining };
      this.handleCheckBox = this.handleCheckBox.bind(this);

    }

    handleCheckBox = event => {  

      this.setState({ checkbox: event.target.previousSibling.checked});

      if(this.state.checkbox || this.props.game.isRun){
        this.props.setStatusModeGame();
      }else{
        this.props.setStatusModeTraining();
      }

    };

    render(props) {
      return <header class="header">
                  <div class="header__navigation">
                    {this.props.children}
                  </div>
                  <div class="header__switch">
                    <div class="switcher">
                      <input class="switcher__input" id="switcher" type="checkbox" name="switcher" defaultChecked={this.state.checkbox} onChange={this.checkbox}/>
                      <label class="switcher__label" htmlFor="switcher" 
                      onClick={this.handleCheckBox}></label>
                    </div>
                  </div>
              </header>;
  }
}
const mapStateToProps = (state) => state;
const mapDispatchToProps = {setStatusModeTraining , setStatusModeGame}

const StartContainer = connect(mapStateToProps, mapDispatchToProps)(Header)

export default StartContainer


