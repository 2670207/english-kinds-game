import React from 'react';


export default class GameSuccessComponent extends React.Component {
    
    render(){
        return (
            <div class="page">
                <div class="final">
                    <img class="final__picture" src="/img/congrats-minion.png" heigh="150" />
                </div>
            </div>
        );
    }

    componentWillReceiveProps(){
        const audio = new Audio('/audio/success.mp3');
        audio.play();
    }



}