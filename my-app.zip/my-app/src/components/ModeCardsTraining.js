import React from 'react';
import CardsPresetStorage from '../CardsPresetStorage';
export default class Card extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            id: this.props.id,
            card: this.props.card,
            isRotate: false
        }
        this.onRotate = this.onRotate.bind(this);
        this.offRotate = this.offRotate.bind(this);
        this.play = this.play.bind(this);
    }
   
    render() {
        return <div className={ 'training__flip-card ' +  (this.state.isRotate ? "training__flip-card-translate " : "") }  onMouseLeave={this.offRotate} >
                <div class="training__flip-card-container">
                        <div class="training__flip-card-front" style={{ backgroundImage: `url("/${this.state.card.image}")` }} onClick={this.play}>
                            <div class="training__card-text">{this.state.card.word}</div>
                            <div class="training__card-rotate" onClick={this.onRotate}></div>
                        </div>
                        <div class="training__flip-card-back" style={{ backgroundImage: `url("/${this.state.card.image}")` }}>
                            <div class="training__card-text">{this.state.card.translation}</div>
                        </div>
                </div>
            </div>
         
  }

  offRotate(){
    this.setState(prevState => ({ isRotate: false}));
  }
  onRotate(event){
    this.setState(prevState => ({ isRotate: true }));
    event.stopPropagation();

  }

  play(event){
    const audio = new Audio(`/${this.state.card.audioSrc}`)
    audio.play();
  }

}