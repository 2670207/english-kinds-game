import React from 'react';
import { connect } from 'react-redux';
import {setStatusGamePlay, setStatusGameStop} from '../../redux/actions';
import GameFinishSuccess from "../GameFinishSuccess";

class CardsForGame extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
          stars: [],
          stack: [...this.props.items].sort( () => .5 - Math.random()),
          cards: props.items,
        }

        this.startGameHandler = this.startGameHandler.bind(this);
        this.playNewWord = this.playNewWord.bind(this);
        this.clickByCardHandler = this.clickByCardHandler.bind(this);

        console.log('CardsForGame');
    }

    componentWillReceiveProps(nextProps){
      if(JSON.stringify(nextProps.items) !== JSON.stringify(this.props.items)){
        nextProps.setStatusGameStop();
        this.forceUpdate();
        this.setState({
          stars: [],
          cards: [...this.props.items].sort( () => .5 - Math.random()),
          stack: [...this.props.items].sort( () => .5 - Math.random())
        });
      }
    }
  
    
    render() {
   
      return (
        <div className={this.props.game.isRun ? 'game started' : 'game' }> 
          <div class="game__container">
              {this.state.stack.map((card, index) => {
                  return (  
                    <div  className={`game__card`} data-card-word={card.word} style={{ backgroundImage: `url("/${card.image}")` }} ket={index} onClick={this.clickByCardHandler}></div>  
                  )
              })}
          </div>
          

          <div class="game__stars">
            {this.state.stars.map((star, index) => {
                    return (  
                      <div className={`game__star game__star--${star}`}></div>
                    )
            })}
          </div>
          <div class="game__controls">
                {this.renderControl()}
          </div>
      </div>
      )    
    }

    renderControl(){
      if(this.props.game.isRun)
        return (<a class="game__button-paly" onClick={this.playNewWord}></a>);
      return (<a class="game__button-start" onClick={this.startGameHandler}>start game</a>);
      
    }

    clickByCardHandler(event){

      const card = event.target;
      const length = this.state.stack.length - 1;

      if(length){
        if(this.state.stack[length].word === event.target.dataset.cardWord){

          this.setState({ stars: this.state.stars.concat('success') })
          card.classList.add('success');

          this.state.stack.pop();
          const audio = new Audio(`/audio/correct.mp3`);
          audio.play();
  
          this.playNewWord();
  
          if(length === 0){
            this.props.history.push('/game-success')
          }
          
        
        }else{
          this.setState({ stars: this.state.stars.concat('error') })
          const audio = new Audio(`/audio/error.mp3`);
          audio.play();
  
        }
      }else{
        (this.props.items.length - 1) === this.state.stars.length ? this.props.history.push('/game-success') : this.props.history.push('/game-failed')
      }
      
    }


    startGameHandler(){
      this.props.setStatusGamePlay();
      this.playNewWord();
    }

    playNewWord(){
      if(this.state.stack.length){
        const audio = new Audio(`/${this.state.stack[this.state.stack.length - 1].audioSrc}`);
        audio.play();
      }
    }
}

const mapStateToProps = (state) => state;
const mapDispatchToProps = {setStatusGamePlay, setStatusGameStop} 

const StartContainer = connect(mapStateToProps, mapDispatchToProps)(CardsForGame)

export default StartContainer
