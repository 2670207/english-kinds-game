import React from 'react';

export default class CardsForTraining extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div class="training"> 
        {this.props.items.map((card, index) => {
            return (    
                <div className={'training__flip-card'} onMouseLeave={this.offRotate} 
                data-card-id={index} data-card-audio-src={card.audioSrc}>
                  <div class="training__flip-card-container">
                    <div class="training__flip-card-front" style={{ backgroundImage: `url("/${card.image}")` }} onClick={this.play}>
                      <div class="training__card-text">{card.word}</div>
                      <div class="training__card-rotate" onClick={this.onRotate}></div>
                    </div>
                    <div class="training__flip-card-back" style={{ backgroundImage: `url("/${card.image}")` }}>
                      <div class="training__card-text">{card.translation}</div>
                    </div>
                  </div>
                </div>
            )
        })}
    </div>
    )    
  }

  offRotate(event) {
    const containerCard = event.target.closest('[data-card-id]');
    containerCard.classList.remove('training__flip-card-translate');
  }

  onRotate(event) {
    const containerCard = event.target.closest('[data-card-id]');
    containerCard.classList.add('training__flip-card-translate');
    event.stopPropagation();

  }

  play(event) {
    const containerCard = event.target.closest('[data-card-id]');
    const audio = new Audio(`/${containerCard.dataset.cardAudioSrc}`);

    audio.play();
  }


}