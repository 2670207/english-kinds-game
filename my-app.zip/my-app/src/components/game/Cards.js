import React from 'react';
import { connect } from 'react-redux';
import CardsForGame from './CardsForGame';
import CardsForTraining from './CardsForTraining';
import CardsPresetStorage from '../../CardsPresetStorage';

class Cards extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            items: [...CardsPresetStorage.find((item, index) =>  Number.parseInt(this.props.match.params.id, 10) === index)],
        }

    }

    componentWillReceiveProps(nextProps){
        this.setState({
            items: [...CardsPresetStorage.find((item, index) =>  Number.parseInt(nextProps.match.params.id, 10) === index)]
        });
    }

    render() {
        return this.props.game.isModeTraining ? <CardsForTraining items={this.state.items} /> :  <CardsForGame items={this.state.items} history={this.props.history}/> ;
    }
}

const mapStateToProps = (state) => {
    return state;
}

const StartContainer = connect(mapStateToProps, null)(Cards)

export default StartContainer
  