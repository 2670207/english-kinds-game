import React from 'react';
import CardsPresetStorage from '../../CardsPresetStorage';
import { connect } from 'react-redux';
import CardsForGame from './CardsForGame';
import CardsForTraining from './CardsForTraining';

class Cards extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            items: [...CardsPresetStorage.find((item, index) =>  Number.parseInt(this.props.match.params.id, 10) === index)],
            mode: props.game.mode,
        }
  
        console.log(props.game.mode, 'test'); 
    }
    
    componentWillReceiveProps(){
        this.state.items =  [...CardsPresetStorage.find((item, index) =>  Number.parseInt(this.props.match.params.id, 10) === index)];
    }

    render() {
        return this.props.game.mode === 'game' ?  <CardsForGame/> : <CardsForTraining/>;
    }
}

const mapStateToProps = (state) => {
    return state;
}

const StartContainer = connect(mapStateToProps, null)(Cards)

export default StartContainer
  