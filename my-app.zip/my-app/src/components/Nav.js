import React from 'react';
import { Link } from "react-router-dom";

export default class Hav extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
            items: ['Action (set A)', 'Action (set B)', 'Action (set C)', 'Animal (set A)', 'Animal (set B)', 'Clothes', 'Emotions', 'Adjective'],
        }; 
        this.toggleMenu = this.toggleMenu.bind(this);
    }
    
    render() {
      return <div>
          <div className={ 'header__navigation-button-toggle ' +  (this.state.isOpen ? "active " : "") } onClick={this.toggleMenu}></div>
                <ul className={ 'header__menu ' +  (this.state.isOpen ? "active " : "") }>
                    {this.state.items.map((item, index) => {
                        return <li class="header__menu-item">
                                <Link to={`/category/${index}`} className="header__menu-link"  onClick={this.toggleMenu}>{item}</Link>
                            </li>
                    })} 
                </ul>
          </div>;
    }
    toggleMenu(){
        this.setState(prevState => ({
            isOpen: !prevState.isOpen
        }));
    }
}